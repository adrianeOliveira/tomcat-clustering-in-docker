# Criar POC de clusterização com Tomcat e load balance

Priority: P1
Status: In Progress 🙌
Tags: Mentoria, Trabalho
Tecnologia ou linguagem: Docker, Linux, Tomcat

Dificuldades:

- No início quebrei cabeça em criar dois nós do tomcat seguindo a documentação da própria Apache Tomcat. Tentei criar esses dois nós na minha máquina e conforme os erros que iam acontecendo eu pesquisava no google dando preferencia pros links da própria doc. Infelizmente não anotei os erros, só lembro do ultimo que era ao criar o arquivo setenv com as informações do pid e do path da jdk, o deploy falhava em um dos nós pois o pid ja tava sendo usado pelo primeiro.
- Depois do rost passar o link do [devmedia](https://www.devmedia.com.br/configurando-um-cluster-de-tomcat-com-balanceamento-de-carga/22631) e sugerir de usar docker no lugar de VM, fui pesquisar sobre. Achei vários tutoriais mas sempre usando nginx, como não sabia o que era, nem me preocupei em acessar os links, e fui tentando usando a doc do docker e do tomcat, sem sucesso.
    - Primeiro tentei criar containeres do ubuntu e baixar o tomcat no container (sem sucesso)
    - Segundo me toquei que poderia ja ter imagem pronta do tomat e passei a usa-la, mas tive problemas pra acessar a pagina inicial e a de gerenciamento pra fazer deploy:
        1. [localhost:8080](http://localhost:8080) retornava 404 mas era por conta da pasta webapps vazia, o que ja **estava explicado na [pagina oficial do tomcat no dockerhub](https://hub.docker.com/_/tomcat) e eu não li direito tudo**
        2. tb não prestei atenção [nesse tutorial](https://www.ramkitech.com/2015/10/docker-tomcat-clustering.html) pra conseguir rodar os clusters usando o nginx (load balance), pq queria entender cada linha no arquivo docker-compose.yml, que o autor disponibiliza, antes de assistir o vídeo (que ele tb explica bastante coisa mas só entendi algumas partes e ai a informação ficou solta).
        3. Ao finalmente assistir o vídeo (mais de uma vez) e sem ficar avançando consegui fazer rodar

Como criar:

Tenho as seguintes anotações de como rodar utilizando os  arquivos descritos a seguir em cada nó (pra resolver os problemas que enfrentei quando eu decidi em criar um unico container antes de sair criando 3 com load balance):

1. A pasta `webapps` vem vazia e seu conteúdo está em `webapps.dist` o que gera o erro 404 ao acessar a home do container;
2. Para configurar o container como cluster precisa adicionar a tag `<Cluster/>` no arquivo *conf/web.xml* (usei a config disponível na [doc online do tomcat](https://tomcat.apache.org/tomcat-9.0-doc/cluster-howto.html)). E usei o arquivo nos outros nós (linkando pelo `volume` do docker);
3. Para ter acesso a pagina locahost:port/manager (onde faz o deploy de aplicações) precisa configurar um usuário e senha junto com a role de permissões em *conf/tomcat-users.xml* ([link pra doc](https://tomcat.apache.org/tomcat-9.0-doc/manager-howto.html));
4. A tag `<Valve/>`  é responsável por configurar o acesso remoto ao container e a aplicação publicada, então pra acessar fora do container docker, precisa alterar a mesma que fica no arquivo *conf/context.xml* (no meu caso eu só comentei mesmo pra fazer funcionar - [link da doc](https://tomcat.apache.org/tomcat-9.0-doc/config/valve.html#Remote_Address_Valve));
5. Ao criar o container com a imagem do nginx, precisa criar links dos nós do tomcat pra isso é necessário configurar na criação do container e dentro do arquivo *default.conf* do próprio nginx. Assim ele vai conseguir redirecionar as requisições pra cada nó do tomcat;
6. Não Consegui fazer o deploy pelo link do nginx, só pelo link de um dos containers;
7. o arquivo final docker-compose.yml (sim, o conteúdo de server.xml, contex.xml e tomcat-users-xml tem que ter o mesmo em todos os nós, o próprio docker gerencia o IP de cada container):
    
    ```yaml
    portal:
      image: nginx
      ports:
       - "8080:80"
      volumes:
       - /home/adriane/dev/tomcat/default.conf:/etc/nginx/conf.d/default.conf
      links:
       - node01:node01
       - node02:node02
       - node03:node03
    node01:
      image: tomcat
      volumes:
       - <host-path-to-file>/server.xml:/usr/local/tomcat/conf/server.xml
       - <host-path-to-file>/tomcat-users.xml:/usr/local/tomcat/conf/tomcat-users.xml
       - <host-path-to-file>/context.xml:/usr/local/tomcat/webapps/manager/META-INF/context.xml
       - <host-path-to-file>/webapps:/usr/local/tomcat/webapps/
    node02:
      image: tomcat
      volumes:
       - <host-path-to-file>/server.xml:/usr/local/tomcat/conf/server.xml
       - <host-path-to-file>/tomcat-users.xml:/usr/local/tomcat/conf/tomcat-users.xml
       - <host-path-to-file>/context.xml:/usr/local/tomcat/webapps/manager/META-INF/context.xml
       - <host-path-to-file>/webapps:/usr/local/tomcat/webapps/
    node03:
      image: tomcat
      volumes:
       - <host-path-to-file>/server.xml:/usr/local/tomcat/conf/server.xml
       - <host-path-to-file>/tomcat-users.xml:/usr/local/tomcat/conf/tomcat-users.xml
       - <host-path-to-file>/context.xml:/usr/local/tomcat/webapps/manager/META-INF/context.xml
       - <host-path-to-file>/webapps:/usr/local/tomcat/webapps/
    ```
    

Para ver qual o IP de cada container e do nginx é só usar o comando `inspect` do docker (com `| grep` para exibir só o IP):

```bash
docker inspect tomcat_portal_1 | grep IPAddress
```

Ai é só acessar `<tomcat-ip>:<port>` ou `nginx-ip`  no navegador.